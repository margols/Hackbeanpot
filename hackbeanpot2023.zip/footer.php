 <!--====== Start Footer ======-->
 <footer class="footer-area">
        <div class="footer-wrapper-one dark-black pt-90">
            <div class="copyright-area">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <div class="copyright-text">
                                <p>Copyright &copy; 2021. All rights reserved to <span>Team MOBCG</span></p>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="copyright-link">
                                <ul>
                                    <li><a href="#">Terms & Conditions</a></li>
                                    <li><a href="#">Services</a></li>
                                    <li><a href="#">Career</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer><!--====== End Footer ======-->
    <!--====== back-to-top ======-->
    <a href="#" class="back-to-top"><i class="ti-angle-up"></i></a>
    <!--====== Jquery js ======-->
    <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
    <!--====== Popper js ======-->
    <script src="assets/js/popper.min.js"></script>
    <!--====== Bootstrap js ======-->
    <script src="assets/js/bootstrap.min.js"></script>
    <!--====== Slick js ======-->
    <script src="assets/js/slick.min.js"></script>
    <!--====== Magnific Popup js ======-->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <!--====== Isotope js ======-->
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <!--====== Imagesloaded js ======-->
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <!--====== Nice-select js ======-->
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <!--====== counterup js ======-->
    <script src="assets/js/jquery.counterup.min.js"></script>
    <!--====== waypoints js ======-->
    <script src="assets/js/jquery.waypoints.js"></script>
    <!--====== Ui js ======-->
    <script src="assets/js/jquery-ui.min.js"></script>
    <!--====== Wow js ======-->
    <script src="assets/js/wow.min.js"></script>
    <!--====== Main js ======-->
    <script src="assets/js/main.js"></script>