<!DOCTYPE html>
<html lang="en">
<?php include 'header.php' ;?>

        <!--====== Start Listing Details Section ======-->
        <section class="listing-details-section pt-120 pb-90">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="listing-details-wrapper listing-details-wrapper-two">
                            <div class="listing-info-area mb-30">
                                <div class="row align-items-center">
                                    <div class="col-md-8">
                                        <div class="listing-info-content">
                                            <ul class="ratings ratings-four">
                                                <li class="star"><i class="flaticon-star-1"></i></li>
                                                <li class="star"><i class="flaticon-star-1"></i></li>
                                                <li class="star"><i class="flaticon-star-1"></i></li>
                                                <li class="star"><i class="flaticon-star-1"></i></li>
                                                <li class="star"><i class="flaticon-star-1"></i></li>
                                                <li><span><a href="#">(27 Reviews)</a></span></li>
                                            </ul>
                                            <h3 class="title">Boston General Store</h3>
                                            <div class="listing-meta">
                                                <ul>
                                                    <li><span><i class="ti-location-pin"></i>Brookline, MA</span></li>
                                                    <li><span><i class="ti-tablet"></i><a href="tel:(617) 232-0103">(617) 232-0103</a></span></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="button">
                                            <a href="listing-grid.html" class="icon-btn"><i class="ti-heart"></i></a>
                                            <a href="listing-grid.html" class="icon-btn"><i class="ti-share"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="listing-thumbnail mb-30">
                                <img src="assets/hbpimages/Boston General Store XL.jpg" alt="listing image">
                            </div>
                            <div class="listing-content mb-30">
                                <h3 class="title">The Sustainable Nest</h3>
                                <p>
                                    Boston General Store is a family-owned and operated business
                                    that prioritizes sustainability in all of their operations.
                                    They offer a diverse range of home goods and accessories,
                                    perfect for customers looking to enhance their living spaces.
                                    With locations in both Brookline and Dedham, Boston General
                                    Store is a convenient shopping destination for anyone in the
                                    Greater Boston area. Go visit today and see how they can
                                    help you create a comfortable and environmentally-friendly home!
                                </p>
                            </div>
                            <div class="listing-review-box mb-50">
                                <h4 class="title">Customer Review</h4>
                                <ul class="review-list">
                                    <li class="review">
                                        <div class="thumb">
                                            <img src="assets/hbpimages/William S.jpg" alt="review image">
                                        </div>
                                        <div class="review-content">
                                            <h5>William S.</h5>
                                            <span class="date">Oct 22, 2015</span>
                                            <p>
                                                “The latest addition to Coolidge Corner neighborhood,
                                                Boston General Store seeks to provide a modernized
                                                version of the purveyors of old.”
                                            </p>
                                            <div class="content-meta d-flex align-items-center justify-content-between">
                                                <ul class="ratings ratings-five">
                                                    <li><span class="av-rate">4</span></li>
                                                    <li class="star"><i class="flaticon-star-1"></i></li>
                                                    <li class="star"><i class="flaticon-star-1"></i></li>
                                                    <li class="star"><i class="flaticon-star-1"></i></li>
                                                    <li class="star"><i class="flaticon-star-1"></i></li>
                                                    <li class="star"><i class="flaticon-star-1"></i></li>
                                                </ul>
                                                <a href="#" class="reply"><i class="ti-share-alt"></i>Reply</a>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="review">
                                        <div class="thumb">
                                            <img src="assets/hbpimages/Jackie L.jpg" alt="review image">
                                        </div>
                                        <div class="review-content">
                                            <h5>Jackie L.</h5>
                                            <span class="date">Dec 22, 2016</span>
                                            <p>
                                                “I was pleased they could gift wrap it for me as it
                                                made my life easier and they did a really nice job
                                                (they wrapped the gifts in kraft paper and twine).”
                                            </p>
                                            <div class="content-meta d-flex align-items-center justify-content-between">
                                                <ul class="ratings ratings-five">
                                                    <li><span class="av-rate">4</span></li>
                                                    <li class="star"><i class="flaticon-star-1"></i></li>
                                                    <li class="star"><i class="flaticon-star-1"></i></li>
                                                    <li class="star"><i class="flaticon-star-1"></i></li>
                                                    <li class="star"><i class="flaticon-star-1"></i></li>
                                                    <li class="star"><i class="flaticon-star-1"></i></li>
                                                </ul>
                                                <a href="#" class="reply"><i class="ti-share-alt"></i>Reply</a>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="review">
                                        <div class="thumb">
                                            <img src="assets/hbpimages/Danae K.jpg" alt="review image">
                                        </div>
                                        <div class="review-content">
                                            <h5>Danae K.</h5>
                                            <span class="date">Dec 13, 2015</span>
                                            <p>
                                                “Very cute place in the heart of Coolidge Corner to
                                                come get Christmas gifts for friends and family.”
                                            </p>
                                            <div class="content-meta d-flex align-items-center justify-content-between">
                                                <ul class="ratings ratings-five">
                                                    <li><span class="av-rate">4</span></li>
                                                    <li class="star"><i class="flaticon-star-1"></i></li>
                                                    <li class="star"><i class="flaticon-star-1"></i></li>
                                                    <li class="star"><i class="flaticon-star-1"></i></li>
                                                    <li class="star"><i class="flaticon-star-1"></i></li>
                                                    <li class="star"><i class="flaticon-star-1"></i></li>
                                                </ul>
                                                <a href="#" class="reply"><i class="ti-share-alt"></i>Reply</a>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="listing-review-form mb-30">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h4 class="title">Write a Review</h4>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-rating">
                                            <ul class="ratings">
                                                <li><span>Rate Here:</span></li>
                                                <li class="star"><i class="flaticon-star-1"></i></li>
                                                <li class="star"><i class="flaticon-star-1"></i></li>
                                                <li class="star"><i class="flaticon-star-1"></i></li>
                                                <li class="star"><i class="flaticon-star-1"></i></li>
                                                <li class="star"><i class="flaticon-star-1"></i></li>
                                            </ul>
                                            <span>(27 Reviews)</span>
                                        </div>
                                    </div>
                                </div>
                                <form>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form_group">
                                                <textarea class="form_control" placeholder="Write Message" name="message"></textarea>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form_group">
                                                <input type="text" class="form_control" placeholder="Your name" name="name" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form_group">
                                                <input type="email" class="form_control" placeholder="Email here" name="email" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <div class="form_group">
                                                <div class="single-checkbox d-flex">
                                                    <input type="checkbox" id="check4" name="checkbox">
                                                    <label for="check4"><span>Save my name, email, and website in this browser for the next time i comment.</span></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <div class="form_group">
                                                <button class="main-btn icon-btn">Submit Review</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="sidebar-widget-area">
                            <div class="widget contact-info-widget mb-30">
                                <div class="contact-info-widget-wrap">
                                    <div class="contact-info-content">
                                        <h4 class="widget-title">Contact Info</h4>
                                        <div class="info-list">
                                            <p><i class="ti-tablet"></i><a href="tel:(617) 232-0103">(617) 232-0103</a></p>
                                            <p><i class="ti-location-pin"></i>305 Harvard St, Brookline, MA 02446</p>
                                            <p><i class="ti-world"></i><a href="http://www.bostongeneralstore.com/">www.bostongeneralstore.com</a></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="widget business-hour-widget mb-30">
                                <h4 class="widget-title">Business Hour</h4>
                                <ul class="time-info">
                                    <li><span class="day">Monday</span><span class="time">11AM - 7PM</span></li>
                                    <li><span class="day">Tuesday</span><span class="time">11AM - 7PM</span></li>
                                    <li><span class="day">Wednesday</span><span class="time">11AM - 7PM</span></li>
                                    <li><span class="day">Thursday</span><span class="time">11AM - 7PM</span></li>
                                    <li><span class="day">Friday</span><span class="time">11AM - 7PM</span></li>
                                    <li><span class="day">Saturday</span><span class="time">10AM - 7PM</span></li>
                                    <li><span class="day">Sunday</span><span class="time">11AM - 6PM</span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section><!--====== End Listing Details Section ======-->

        <?php include 'footer.php' ;?>

    </body>
</html>