<!DOCTYPE html>
<html lang="en">
<?php include 'header.php' ;?>

<!--====== Start Listing Details Section ======-->
<section class="listing-details-section pt-120 pb-90">
  <div class="container">
    <div class="row">
      <div class="col-lg-8">
        <div class="listing-details-wrapper listing-details-wrapper-two">
          <div class="listing-info-area mb-30">
            <div class="row align-items-center">
              <div class="col-md-8">
                <div class="listing-info-content">
                  <ul class="ratings ratings-four">
                    <li class="star"><i class="flaticon-star-1"></i></li>
                    <li class="star"><i class="flaticon-star-1"></i></li>
                    <li class="star"><i class="flaticon-star-1"></i></li>
                    <li class="star"><i class="flaticon-star-1"></i></li>
                    <li class="star"><i class="flaticon-star-1"></i></li>
                    <li><span><a href="#">(152 Reviews)</a></span></li>
                  </ul>
                  <h3 class="title">Boomerangs</h3>
                  <div class="listing-meta">
                    <ul>
                      <li><span><i class="ti-location-pin"></i>Jamaica Plain, MA</span></li>
                      <li><span><i class="ti-tablet"></i><a href="tel:(617) 524-5120">(617) 524-5120</a></span></li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="button">
                  <a href="listing-grid.html" class="icon-btn"><i class="ti-heart"></i></a>
                  <a href="listing-grid.html" class="icon-btn"><i class="ti-share"></i></a>
                </div>
              </div>
            </div>
          </div>
          <div class="listing-thumbnail mb-30">
            <img src="assets/hbpimages/Boomerangs XL.jpg" alt="listing image">
          </div>
          <div class="listing-content mb-30">
            <h3 class="title">Thrift for a Cause: The Boomerangs Emporium</h3>
            <p>
              Boomerangs is a family of thrift stores with a purpose. Located in Jamaica Plain,
              Boomerangs provides critical funding to AIDS Actions through the sale of high-quality
              new, vintage, and gently-loved merchandise. Shopping at Boomerangs not only helps you
              score great deals on unique items, but it also supports a vital cause. From vintage
              clothing and furniture to kitchenware and electronics, Boomerangs has something for
              everyone. Visit today and join the movement to make a difference.
            </p>
          </div>
          <div class="listing-review-box mb-50">
            <h4 class="title">Customer Review</h4>
            <ul class="review-list">
              <li class="review">
                <div class="thumb">
                  <img src="assets/hbpimages/Fiona D..jpeg" alt="review image">
                </div>
                <div class="review-content">
                  <h5>Fiona D.</h5>
                  <span class="date">Aug 13, 2018</span>
                  <p>
                    “Niche is one of the few plant nurseries in the Boston area and visiting the
                    one in Cambridge is always a treat!”
                  </p>
                  <div class="content-meta d-flex align-items-center justify-content-between">
                    <ul class="ratings ratings-five">
                      <li><span class="av-rate">5</span></li>
                      <li class="star"><i class="flaticon-star-1"></i></li>
                      <li class="star"><i class="flaticon-star-1"></i></li>
                      <li class="star"><i class="flaticon-star-1"></i></li>
                      <li class="star"><i class="flaticon-star-1"></i></li>
                      <li class="star"><i class="flaticon-star-1"></i></li>
                    </ul>
                    <a href="#" class="reply"><i class="ti-share-alt"></i>Reply</a>
                  </div>
                </div>
              </li>
              <li class="review">
                <div class="thumb">
                  <img src="assets/hbpimages/Matt P..jpeg" alt="review image">
                </div>
                <div class="review-content">
                  <h5>Matt P.</h5>
                  <span class="date">Aug 31, 2020</span>
                  <p>
                    “Ranging from cacti to many jungle plants with different geniuses.”
                  </p>
                  <div class="content-meta d-flex align-items-center justify-content-between">
                    <ul class="ratings ratings-five">
                      <li><span class="av-rate">5</span></li>
                      <li class="star"><i class="flaticon-star-1"></i></li>
                      <li class="star"><i class="flaticon-star-1"></i></li>
                      <li class="star"><i class="flaticon-star-1"></i></li>
                      <li class="star"><i class="flaticon-star-1"></i></li>
                      <li class="star"><i class="flaticon-star-1"></i></li>
                    </ul>
                    <a href="#" class="reply"><i class="ti-share-alt"></i>Reply</a>
                  </div>
                </div>
              </li>
              <li class="review">
                <div class="thumb">
                  <img src="assets/hbpimages/Jenny S..jpeg" alt="review image">
                </div>
                <div class="review-content">
                  <h5>Jenny S.</h5>
                  <span class="date">Nov. 11, 2018</span>
                  <p>
                    “SELECTION: Wide variety of plants, in all shapes and sizes, are offered.”
                  </p>
                  <div class="content-meta d-flex align-items-center justify-content-between">
                    <ul class="ratings ratings-five">
                      <li><span class="av-rate">5</span></li>
                      <li class="star"><i class="flaticon-star-1"></i></li>
                      <li class="star"><i class="flaticon-star-1"></i></li>
                      <li class="star"><i class="flaticon-star-1"></i></li>
                      <li class="star"><i class="flaticon-star-1"></i></li>
                      <li class="star"><i class="flaticon-star-1"></i></li>
                    </ul>
                    <a href="#" class="reply"><i class="ti-share-alt"></i>Reply</a>
                  </div>
                </div>
              </li>
            </ul>
          </div>
          <div class="listing-review-form mb-30">
            <div class="row">
              <div class="col-md-6">
                <h4 class="title">Write a Review</h4>
              </div>
              <div class="col-md-6">
                <div class="form-rating">
                  <ul class="ratings">
                    <li><span>Rate Here:</span></li>
                    <li class="star"><i class="flaticon-star-1"></i></li>
                    <li class="star"><i class="flaticon-star-1"></i></li>
                    <li class="star"><i class="flaticon-star-1"></i></li>
                    <li class="star"><i class="flaticon-star-1"></i></li>
                    <li class="star"><i class="flaticon-star-1"></i></li>
                  </ul>
                  <span>(152 Reviews)</span>
                </div>
              </div>
            </div>
            <form>
              <div class="row">
                <div class="col-lg-12">
                  <div class="form_group">
                    <textarea class="form_control" placeholder="Write Message" name="message"></textarea>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="form_group">
                    <input type="text" class="form_control" placeholder="Your name" name="name" required>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="form_group">
                    <input type="email" class="form_control" placeholder="Email here" name="email" required>
                  </div>
                </div>
                <div class="col-lg-12">
                  <div class="form_group">
                    <div class="single-checkbox d-flex">
                      <input type="checkbox" id="check4" name="checkbox">
                      <label for="check4"><span>Save my name, email, and website in this browser for the next time i comment.</span></label>
                    </div>
                  </div>
                </div>
                <div class="col-lg-12">
                  <div class="form_group">
                    <button class="main-btn icon-btn">Submit Review</button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>

      <div class="col-lg-4">
        <div class="sidebar-widget-area">
          <div class="widget contact-info-widget mb-30">
            <div class="contact-info-widget-wrap">
              <div class="contact-info-content">
                <h4 class="widget-title">Contact Info</h4>
                <div class="info-list">
                  <p><i class="ti-tablet"></i><a href="tel:(617) 524-5120">(617) 524-5120</a></p>
                  <p><i class="ti-location-pin"></i>716 Centre St, Jamaica Plain, MA 02130</p>
                  <p><i class="ti-world"></i><a href="http://www.shopboomerangs.org/">www.shopboomerangs.org</a></p>
                </div>
              </div>
            </div>
          </div>
          <div class="widget business-hour-widget mb-30">
            <h4 class="widget-title">Business Hour</h4>
            <ul class="time-info">
              <li><span class="day">Monday</span><span class="time">Closed</span></li>
              <li><span class="day">Tuesday</span><span class="time">Closed</span></li>
              <li><span class="day">Wednesday</span><span class="time">12PM - 6PM</span></li>
              <li><span class="day">Thursday</span><span class="time">2PM - 6PM</span></li>
              <li><span class="day">Friday</span><span class="time">12PM - 6PM</span></li>
              <li><span class="day">Saturday</span><span class="time">12PM - 5PM</span></li>
              <li><span class="day">Sunday</span><span class="time">12PM - 5PM</span></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</section><!--====== End Listing Details Section ======-->

<?php include 'footer.php' ;?>

</body>
</html>