<!DOCTYPE html>
<html lang="en">
<?php include 'header.php' ;?>
    <!--====== Start Hero Section ======-->
    <section class="hero-area">
        <div class="breadcrumbs-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="page-title">
                            <h1 class="title">Explore</h1>
                            <ul class="breadcrumbs-link">
                                <li><a href="index.html">Home</a></li>
                                <li class="active">Explore</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--====== End Hero Section ======-->
    <!--====== Start Listing Section ======-->
    <section class="listing-grid-area pt-120 pb-90">
        <div class="container">
            <div class="row">

                <div class="col-lg-12">

                    <div class="listing-grid-wrapper">
                        <div class="row">
                            <div class="col-md-4 col-sm-12">
                                <div class="listing-item listing-grid-item-two mb-30">
                                    <div class="listing-thumbnail">
                                        <img src="images/museum.png" alt="Listing Image">
                                        <a href="local-business.php" class="cat-btn"><i class="flaticon-government"></i></a>

                                    </div>
                                    <div class="listing-content">
                                        <h3 class="title"><a href="local-business.php">Local Businesses</a></h3>


                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-12">
                                <div class="listing-item listing-grid-item-two mb-30">
                                    <div class="listing-thumbnail">
                                        <img src="images/museum.png" alt="Listing Image">
                                        <a href="thrift.php" class="cat-btn"><i class="flaticon-government"></i></a>

                                    </div>
                                    <div class="listing-content">
                                        <h3 class="title"><a href="thrift.php">Thrift Stores</a></h3>


                                    </div>
                                </div>
                            </div>
                            

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--====== End Listing Section ======-->
    <?php include 'footer.php' ;?>
</body>

</html>