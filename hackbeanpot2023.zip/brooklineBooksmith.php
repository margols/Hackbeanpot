<!DOCTYPE html>
<html lang="en">
<?php include 'header.php' ;?>

<!--====== Start Listing Details Section ======-->
<section class="listing-details-section pt-120 pb-90">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="listing-details-wrapper listing-details-wrapper-two">
                    <div class="listing-info-area mb-30">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <div class="listing-info-content">
                                    <ul class="ratings ratings-five">
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li><span><a href="#">(455 Reviews)</a></span></li>
                                    </ul>
                                    <h3 class="title">Brookline Booksmith</h3>
                                    <div class="listing-meta">
                                        <ul>
                                            <li><span><i class="ti-location-pin"></i>Brookline, MA</span></li>
                                            <li><span><i class="ti-tablet"></i><a href="tel:(617) 566-6660">(617) 566-6660</a></span></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="button">
                                    <a href="listing-grid.html" class="icon-btn"><i class="ti-heart"></i></a>
                                    <a href="listing-grid.html" class="icon-btn"><i class="ti-share"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="listing-thumbnail mb-30">
                        <img src="assets/hbpimages/Brookline Booksmith XL.jpg" alt="listing image">
                    </div>
                    <div class="listing-content mb-30">
                        <h3 class="title">The Page Turner</h3>
                        <p>
                            Discover Brookline Booksmith, a family-owned bookseller with a rich
                            history dating back to 1961. Located in the vibrant neighborhood of
                            Coolidge Corner, they offer a wide range of books for all interests.
                            This Black History Month, they are particularly proud to celebrate the
                            contributions and achievements of the African American community through
                            special events and promotions. Go visit and discover a world of
                            knowledge and creativity.
                        </p>
                    </div>
                    <div class="listing-review-box mb-50">
                        <h4 class="title">Customer Review</h4>
                        <ul class="review-list">
                            <li class="review">
                                <div class="thumb">
                                    <img src="assets/hbpimages/Lisa P..jpeg" alt="review image">
                                </div>
                                <div class="review-content">
                                    <h5>Lisa P.</h5>
                                    <span class="date">Aug 19, 2012</span>
                                    <p>
                                        “Check out the used book cellar in the basement, or browse
                                        their new book displays and magazines upstairs.”
                                    </p>
                                    <div class="content-meta d-flex align-items-center justify-content-between">
                                        <ul class="ratings ratings-five">
                                            <li><span class="av-rate">5</span></li>
                                            <li class="star"><i class="flaticon-star-1"></i></li>
                                            <li class="star"><i class="flaticon-star-1"></i></li>
                                            <li class="star"><i class="flaticon-star-1"></i></li>
                                            <li class="star"><i class="flaticon-star-1"></i></li>
                                            <li class="star"><i class="flaticon-star-1"></i></li>
                                        </ul>
                                        <a href="#" class="reply"><i class="ti-share-alt"></i>Reply</a>
                                    </div>
                                </div>
                            </li>
                            <li class="review">
                                <div class="thumb">
                                    <img src="assets/hbpimages/Christine D..jpeg" alt="review image">
                                </div>
                                <div class="review-content">
                                    <h5>Christine D.</h5>
                                    <span class="date">Aug 20, 2010</span>
                                    <p>
                                        “In this basement there are regular book readings by
                                        authors, knitting clubs, and other wonderful get togethers.”
                                    </p>
                                    <div class="content-meta d-flex align-items-center justify-content-between">
                                        <ul class="ratings ratings-five">
                                            <li><span class="av-rate">5</span></li>
                                            <li class="star"><i class="flaticon-star-1"></i></li>
                                            <li class="star"><i class="flaticon-star-1"></i></li>
                                            <li class="star"><i class="flaticon-star-1"></i></li>
                                            <li class="star"><i class="flaticon-star-1"></i></li>
                                            <li class="star"><i class="flaticon-star-1"></i></li>
                                        </ul>
                                        <a href="#" class="reply"><i class="ti-share-alt"></i>Reply</a>
                                    </div>
                                </div>
                            </li>
                            <li class="review">
                                <div class="thumb">
                                    <img src="assets/hbpimages/Sarah W..jpeg" alt="review image">
                                </div>
                                <div class="review-content">
                                    <h5>Sarah W.</h5>
                                    <span class="date">July 10, 2009</span>
                                    <p>
                                        “I find myself wandering over to the gift section more and
                                        more now, and it is really something special.”
                                    </p>
                                    <div class="content-meta d-flex align-items-center justify-content-between">
                                        <ul class="ratings ratings-five">
                                            <li><span class="av-rate">5</span></li>
                                            <li class="star"><i class="flaticon-star-1"></i></li>
                                            <li class="star"><i class="flaticon-star-1"></i></li>
                                            <li class="star"><i class="flaticon-star-1"></i></li>
                                            <li class="star"><i class="flaticon-star-1"></i></li>
                                            <li class="star"><i class="flaticon-star-1"></i></li>
                                        </ul>
                                        <a href="#" class="reply"><i class="ti-share-alt"></i>Reply</a>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="listing-review-form mb-30">
                        <div class="row">
                            <div class="col-md-6">
                                <h4 class="title">Write a Review</h4>
                            </div>
                            <div class="col-md-6">
                                <div class="form-rating">
                                    <ul class="ratings">
                                        <li><span>Rate Here:</span></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                    </ul>
                                    <span>(455 Reviews)</span>
                                </div>
                            </div>
                        </div>
                        <form>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form_group">
                                        <textarea class="form_control" placeholder="Write Message" name="message"></textarea>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form_group">
                                        <input type="text" class="form_control" placeholder="Your name" name="name" required>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form_group">
                                        <input type="email" class="form_control" placeholder="Email here" name="email" required>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form_group">
                                        <div class="single-checkbox d-flex">
                                            <input type="checkbox" id="check4" name="checkbox">
                                            <label for="check4"><span>Save my name, email, and website in this browser for the next time i comment.</span></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form_group">
                                        <button class="main-btn icon-btn">Submit Review</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="sidebar-widget-area">
                    <div class="widget contact-info-widget mb-30">
                        <div class="contact-info-widget-wrap">
                            <div class="contact-info-content">
                                <h4 class="widget-title">Contact Info</h4>
                                <div class="info-list">
                                    <p><i class="ti-tablet"></i><a href="tel:(617) 566-6660">(617) 566-6660</a></p>
                                    <p><i class="ti-location-pin"></i>279 Harvard St, Brookline, MA 02446</p>
                                    <p><i class="ti-world"></i><a href="http://www.brooklinebooksmith.com/">www.brooklinebooksmith.com</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="widget business-hour-widget mb-30">
                        <h4 class="widget-title">Business Hour</h4>
                        <ul class="time-info">
                            <li><span class="day">Monday</span><span class="time">9AM - 9PM</span></li>
                            <li><span class="day">Tuesday</span><span class="time">9AM - 9:30PM</span></li>
                            <li><span class="day">Wednesday</span><span class="time">9AM - 9:30PM</span></li>
                            <li><span class="day">Thursday</span><span class="time">9AM - 9:30PM</span></li>
                            <li><span class="day">Friday</span><span class="time">9AM - 10PM</span></li>
                            <li><span class="day">Saturday</span><span class="time">9AM - 10PM</span></li>
                            <li><span class="day">Sunday</span><span class="time">10AM - 9PM</span></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><!--====== End Listing Details Section ======-->

<?php include 'footer.php' ;?>

</body>
</html>