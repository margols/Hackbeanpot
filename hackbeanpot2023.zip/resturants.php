<!DOCTYPE html>
<html lang="en">
<?php include 'header.php'; ?>


<body>

    <!--====== Start Hero Section ======-->
    <section class="hero-area">
        <div class="breadcrumbs-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="page-title">
                            <h1 class="title">Eat Page</h1>
                            <ul class="breadcrumbs-link">
                                <li><a href="index.html">Home</a></li>
                                <li class="active">List Layout</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--====== End Hero Section ======-->
    <!--====== Start Listing Section ======-->
    <section class="listing-list-area pt-120 pb-90">
        <div class="container">
            <div class="row">

                <div class="col-lg-8">

                    <div class="listing-list-wrapper">        

                        <div class="listing-item listing-list-item-two mb-60">
                            <div class="listing-thumbnail">
                                <img src="assets/hbpimages/cloverfoodlab.jpeg" alt="Food from clover on table">
                                <div class="thumbnail-meta d-flex justify-content-between align-items-center">
                                    <div class="meta-icon-title d-flex align-items-center">
                                        <div class="icon">
                                            <i class="flaticon-government"></i>
                                        </div>
                                        <div class="title">
                                            <h6>Resturants</h6>
                                        </div>
                                    </div>
                                    <span class="status st-open">Open</span>
                                </div>
                            </div>
                            <div class="listing-content">
                                <h3 class="title"><a href="cloverdetails.php">Clover Food Lab</a></h3>
                                <div class="ratings">
                                    <ul class="ratings ratings-five">
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        
                                    </ul>
                                </div>
                                
                                
                                <div class="listing-meta">
                                    <ul>
                                        <li><span><i class="ti-location-pin"></i>Boston,MA USA</span></li>
                                        <li><span><i class="ti-heart"></i><a href="#">Save</a></span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>


                        <div class="listing-item listing-list-item-two mb-60">
                            <div class="listing-thumbnail">
                                <img src="assets/hbpimages/Boloco_in_Copley_Square,_Boston_MA.jpeg" alt="Image of the resturant">
                                <div class="thumbnail-meta d-flex justify-content-between align-items-center">
                                    <div class="meta-icon-title d-flex align-items-center">
                                        <div class="icon">
                                            <i class="flaticon-dumbbell"></i>
                                        </div>
                                        <div class="title">
                                            <h6>Resturants</h6>
                                        </div>
                                    </div>
                                    <span class="status st-open">Open</span>
                                </div>
                            </div>
                            <div class="listing-content">
                                <h3 class="title"><a href="Bolocodetails.php">Boloco</a></h3>
                                <div class="ratings">
                                    <ul class="ratings ratings-four">
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        
                                    </ul>
                                </div>
                                
                                
                                <div class="listing-meta">
                                    <ul>
                                        <li><span><i class="ti-location-pin"></i>Boston,MA USA</span></li>
                                        <li><span><i class="ti-heart"></i><a href="#">Save</a></span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="listing-item listing-list-item-two mb-60">
                            <div class="listing-thumbnail">
                                <img src="assets/hbpimages/tanantraboston2.jpeg" alt="Image of Resturant">
                                <div class="thumbnail-meta d-flex justify-content-between align-items-center">
                                    <div class="meta-icon-title d-flex align-items-center">
                                        <div class="icon">
                                            <i class="flaticon-suitcase"></i>
                                        </div>
                                        <div class="title">
                                            <h6>Restaurant</h6>
                                        </div>
                                    </div>
                                    <span class="status st-open">Open</span>
                                </div>
                            </div>
                            <div class="listing-content">
                                <h3 class="title"><a href="Tarantadetails.php">Taranta</a></h3>
                                <div class="ratings">
                                    <ul class="ratings ratings-five">
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        
                                    </ul>
                                </div>
                                
                                
                                <div class="listing-meta">
                                    <ul>
                                        <li><span><i class="ti-location-pin"></i>Boston,MA USA</span></li>
                                        <li><span><i class="ti-heart"></i><a href="#">Save</a></span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>


                                   
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--====== End Listing Section ======-->
    <!--====== Start Footer ======-->
    <?php include 'footer.php'; ?>

</body>

</html>