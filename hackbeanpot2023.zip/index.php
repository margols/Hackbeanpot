    <?php
        include 'dbconnect.php';
        $conn = OpenCon();
        echo "Connected Successfully";
        CloseCon($conn);
    ?>

    <?php include 'header.php' ;?>

    <!--====== Start Hero Section ======-->
    <section class="hero-area">
        <div class="hero-wrapper-one">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="hero-content">
                            <h1>A Sustainable <br>Boston</h1>
                            <h3>People don't live in Boston, <br>Boston lives in People</h3>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--====== End Hero Section ======-->
    
    <!--====== Start Category Section ======-->
    <section class="category-area">
        <div class="container">
            <div class="category-wrapper-one">
                <div class="row no-gutters">
                    <div class="col-lg-3 col-md-4 category-column">
                        <div class="category-item category-item-one">
                            <div class="info text-center">
                                <div class="icon">
                                    <i class="flaticon-government"></i>
                                </div>
                                <h6>Explore</h6>
                            </div>
                            <a href="explore-listing-boston.php"  class="category-btn"><i class="ti-arrow-right"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 category-column">
                        <div class="category-item category-item-one">
                            <div class="info text-center">
                                <div class="icon">
                                    <i class="flaticon-serving-dish"></i>
                                </div>
                                <h6>Eat</h6>
                            </div>
                            <a href="eat-listing-boston.php" class="category-btn"><i class="ti-arrow-right"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 category-column">
                        <div class="category-item category-item-one">
                            <div class="info text-center">
                                <div class="icon">
                                    <i class="flaticon-shopping"></i>
                                </div>
                                <h6>Shop</h6>
                            </div>
                            <a href="shop-listing-boston.php" class="category-btn"><i class="ti-arrow-right"></i></a>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-4 category-column">
                        <div class="category-item category-item-one">
                            <div class="info text-center">
                                <div class="icon">
                                    <i class="flaticon-game-controller"></i>
                                </div>
                                <h6>Fun</h6>
                            </div>
                            <a href="fun-listing-boston.php" class="category-btn"><i class="ti-arrow-right"></i></a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!--====== End Category Section ======-->

    <!--====== Start Features Section ======-->
    <section class="features-area">
        <div class="features-wrapper-one pt-120">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="section-title text-center mb-75">
                            <br>
                            <br>
                            <span class="sub-title">Boston To-do's</span>
                            <h2>Our Speciality</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="features-img">
                            <img src="assets/images/features/features-1.jpg" alt="Features Image">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="features-content-box features-content-box-one">
                            <div class="section-title section-title-left mb-25">
                                <h3>Boston 101</h3>
                            </div>
                            <br>
                            <ul class="features-list-one">
                                <li class="list-item">
                                    <div class="icon">
                                        <i class="flaticon-find"></i>
                                    </div>
                                    <div class="content">
                                        <h5>Our Mission</h5>
                                        <p>
										Discover Boston’s rich history and culture, where old meets new and tradition blends with innovation.
										With a thriving start-up scene, this bustling city is also at the forefront of sustainability efforts. 
										Local entrepreneurs are working tirelessly to make Boston a more eco-friendly and socially responsible place to live, work, and play. 
										Immerse yourself in the city’s green revolution by visiting shops that have banned plastic bags and offer products that prioritize the planet.
										Explore our handpicked list of eco-conscious destinations and become a part of Boston’s mission to promote a greener environment, drive economic growth, and achieve social equality. 
										Join us on a journey to explore the city’s green gems and be a part of something truly special.
										</p>
                                    </div>
                                </li>
                                
                                
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--====== End Features Section ======-->

    <br> <br> <br>

    <!--====== Start Testimonial Section ======-->
    <section class="testimonial-area bg_cover pt-110 pb-140"
        style="background-image: url(assets/images/bg/testimonial-bg-1.jpg);">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="section-title section-title-two section-title-white text-center mb-55">
                        <h2><span class="line">Customer</span> Feedback</h2>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="testimonial-wrapper-one text-center">
                        <div class="testimonial-review-area">
                            
                            <div class="testimonial-content-slider-one">
                                <div class="testimonial-item">
                                    <div class="testimonial-content">
                                        <p>"I recently stumbled upon this website and I am so impressed with the wealth of information and resources it provides for living a more sustainable lifestyle in Boston. The site is well-organized and easy to navigate, making it simple to find the information I need. I love the practical tips and advice for reducing my environmental impact, as well as the local resources for eco-friendly products and services. I feel empowered to make a positive change in my own life and in my community, and I am grateful for this valuable resource. Thank you for creating such a fantastic and useful guide for sustainability in Boston!” </p>
                                        <div class="author-info">
                                            <div class="author-title">
                                                <h4>Sam Marjolin</h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="testimonial-item">
                                    <div class="testimonial-content">
                                        <p>multiply given all hath given may meat god abundant appear lioud
                                            fourth madman mane said god dominion great gathering called very shall after
                                            cre ated from fruitful place over the mitual </p>
                                        <div class="author-info">
                                            <div class="author-title">
                                                <h4>Martyn Decode</h4>
                                                <span class="position">Sr. Designer</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="testimonial-item">
                                    <div class="testimonial-content">
                                        <p>multiply given all hath given may meat god abundant appear lioud
                                            fourth madman mane said god dominion great gathering called very shall after
                                            cre ated from fruitful place over the mitual </p>
                                        <div class="author-info">
                                            <div class="author-title">
                                                <h4>Alesha Mature</h4>
                                                <span class="position">Sr. Designer</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="testimonial-item">
                                    <div class="testimonial-content">
                                        <p>multiply given all hath given may meat god abundant appear lioud
                                            fourth madman mane said god dominion great gathering called very shall after
                                            cre ated from fruitful place over the mitual </p>
                                        <div class="author-info">
                                            <div class="author-title">
                                                <h4>Martyn Decode</h4>
                                                <span class="position">Sr. Designer</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--====== End Testimonial Section ======-->


    <!--====== Start Download Section ======-->
    <section class="download-app">
        <div class="download-wrapper-one pt-115">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5">
                        <div class="app-img">
                            <img src="assets/images/app-1.png" alt="App Image">
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="download-content-box download-content-box-one">
                            <div class="section-title section-title-left mb-25">
                                <span class="sub-title">Download App</span>
                                <h2>We are coming soon with our mobile application</h2>
                            </div>
                            <p>Dictumst integer tellus eros quam vestibulum ante tortor mollis adipisn pharetra curae
                                curae and pulvinar porttitor</p>
                            <ul class="button">
                                <li>
                                    <a href="" class="app-btn">
                                        <div class="icon">
                                            <i class="ti-android"></i>
                                        </div>
                                        <div class="info">
                                            <span>Coming Soon on</span>
                                            <h6>Goole Play</h6>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="app-btn">
                                        <div class="icon">
                                            <i class="ti-apple"></i>
                                        </div>
                                        <div class="info">
                                            <span>Coming Soon on</span>
                                            <h6>App Store</h6>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                            <div class="counter-area pt-120">
                                <div class="row">
                                    <div class="col-lg-4 col-md-4 col-ms-12">
                                        <div class="counter-item counter-item-one">
                                            <div class="info">
                                                <h4><span>Some</span>Facts</h4>
                                                <h3><span class="count">220</span> +</h3>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-ms-12">
                                        <div class="counter-item counter-item-one">
                                            <div class="info">
                                                <h4><span>Some</span>Facts</h4>
                                                <h3><span class="count">72</span>K +</h3>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-ms-12">
                                        <div class="counter-item counter-item-one">
                                            <div class="info">
                                                <h4><span>Some</span>Facts</h4>
                                                <h3><span class="count">50</span>K +</h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><!--====== End Download Section ======-->

<br>
<br>

		
   <?php include 'footer.php' ;?>
</body>

