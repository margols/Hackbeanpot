<!DOCTYPE html>
<html lang="en">

<?php include 'header.php' ;?>
    <!--====== Start Hero Section ======-->
    <section class="hero-area">
        <div class="breadcrumbs-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="page-title">
                            <h1 class="title">Explore Page</h1>
                            <ul class="breadcrumbs-link">
                                <li><a href="index.html">Home</a></li>
                                <li class="active">List Layout</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--====== End Hero Section ======-->
    <!--====== Start Listing Section ======-->
    <section class="listing-list-area pt-120 pb-90">
        <div class="container">
            <div class="row">

                <div class="col-lg-8">

                    <div class="listing-list-wrapper">
                        <div class="listing-item listing-list-item-two mb-60">
                            <div class="listing-thumbnail">
                                <img src="assets/hbpimages/MS.jpg" alt="listing Image">
                                <div class="thumbnail-meta d-flex justify-content-between align-items-center">
                                    <div class="meta-icon-title d-flex align-items-center">
                                        <div class="icon">
                                            <i class="flaticon-government"></i>
                                        </div>
                                        <div class="title">
                                            <h6>Museums</h6>
                                        </div>
                                    </div>
                                    <span class="status st-open">Open</span>
                                </div>
                            </div>
                            <div class="listing-content">
                                <h3 class="title"><a href="museum_details_MS.php">Museum of Science</a></h3>
                                <div class="ratings">
                                    <ul class="ratings ratings-three">
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li><span><a href="#">(02 Reviews)</a></span></li>
                                    </ul>
                                </div>
                                <span class="price">$05.00 - $80.00</span>
                                <span class="phone-meta"><i class="ti-tablet"></i><a href="tel:+982653652-05">+98 (265)
                                        3652 - 05</a></span>
                                <div class="listing-meta">
                                    <ul>
                                        <li><span><i class="ti-location-pin"></i>California, USA</span></li>
                                        <li><span><i class="ti-heart"></i><a href="#">Save</a></span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="listing-item listing-list-item-two mb-60">
                            <div class="listing-thumbnail">
                                <img src="assets/hbpimages/MFA.jpg" alt="listing Image">
                                <div class="thumbnail-meta d-flex justify-content-between align-items-center">
                                    <div class="meta-icon-title d-flex align-items-center">
                                        <div class="icon">
                                            <i class="flaticon-chef"></i>
                                        </div>
                                        <div class="title">
                                            <h6>Museums</h6>
                                        </div>
                                    </div>
                                    <span class="status st-open">Open</span>
                                </div>
                            </div>
                            <div class="listing-content">
                                <h3 class="title"><a href="museum_details_MFA.php">Museum of Fine Arts</a></h3>
                                <div class="ratings">
                                    <ul class="ratings ratings-three">
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li><span><a href="#">(02 Reviews)</a></span></li>
                                    </ul>
                                </div>
                                <span class="price">$05.00 - $80.00</span>
                                <span class="phone-meta"><i class="ti-tablet"></i><a href="tel:+982653652-05">+98 (265)
                                        3652 - 05</a></span>
                                <div class="listing-meta">
                                    <ul>
                                        <li><span><i class="ti-location-pin"></i>California, USA</span></li>
                                        <li><span><i class="ti-heart"></i><a href="#">Save</a></span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="listing-item listing-list-item-two mb-60">
                            <div class="listing-thumbnail">
                                <img src="assets/hbpimages/ICA.jpg" alt="listing Image">
                                <div class="thumbnail-meta d-flex justify-content-between align-items-center">
                                    <div class="meta-icon-title d-flex align-items-center">
                                        <div class="icon">
                                            <i class="flaticon-government"></i>
                                        </div>
                                        <div class="title">
                                            <h6>Museums</h6>
                                        </div>
                                    </div>
                                    <span class="status st-open">Open</span>
                                </div>
                            </div>
                            <div class="listing-content">
                                <h3 class="title"><a href="museum_details_ICA.php">Institute of Contemporary Art</a></h3>
                                <div class="ratings">
                                    <ul class="ratings ratings-three">
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li><span><a href="#">(02 Reviews)</a></span></li>
                                    </ul>
                                </div>
                                <span class="price">$05.00 - $80.00</span>
                                <span class="phone-meta"><i class="ti-tablet"></i><a href="tel:+982653652-05">+98 (265)
                                        3652 - 05</a></span>
                                <div class="listing-meta">
                                    <ul>
                                        <li><span><i class="ti-location-pin"></i>California, USA</span></li>
                                        <li><span><i class="ti-heart"></i><a href="#">Save</a></span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--====== End Listing Section ======-->
    <?php include 'footer.php' ;?>
</body>

</html>