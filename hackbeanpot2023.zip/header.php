<head>
    <!--====== Required meta tags ======-->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!--====== Title ======-->
    <title>Boston - To do's</title>
    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="assets/images/favicon.ico" type="image/png">
    <!--====== Bootstrap css ======-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!--====== FontAwesoem css ======-->
    <link rel="stylesheet" href="assets/fonts/themify-icons/themify-icons.css">
    <!--====== Flaticon css ======-->
    <link rel="stylesheet" href="assets/fonts/flaticon/flaticon.css">
    <!--====== Magnific Popup css ======-->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <!--====== Slick css ======-->
    <link rel="stylesheet" href="assets/css/slick.css">
    <!--====== Nice-select css ======-->
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <!--====== Jquery ui css ======-->
    <link rel="stylesheet" href="assets/css/jquery-ui.min.css">
    <!--====== Animate css ======-->
    <link rel="stylesheet" href="assets/css/animate.css">
    <!--====== Default css ======-->
    <link rel="stylesheet" href="assets/css/default.css">
    <!--====== Style css ======-->
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <!--====== Start Preloader ======-->
    <div class="preloader">
        <div class="loader">
            <img src="assets/images/loader.png" alt="loader">
        </div>
    </div>
    <!--====== End Preloader ======-->
    <!--====== Start Header Section ======-->
    <header class="header-area header-area-one">
        <div class="header-top">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-4">
                        <div class="top-social">
                            <ul class="social-link">
                                <li><span>Follow us:</span></li>
                                <li><a href="#"><i class="ti-facebook"></i></a></li>
                                <li><a href="#"><i class="ti-twitter-alt"></i></a></li>
                                <li><a href="#"><i class="ti-pinterest"></i></a></li>
                                <li><a href="#"><i class="ti-dribbble"></i></a></li>
                                <li><a href="#"><i class="ti-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="top-content text-center">
                            <p>Welcome to Boston - To do's <a href="#">Explore, Shop, Eat, Fun</a></p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="top-right">
                            <ul class="d-flex">
                                <li><a href="#"><i class="ti-search"></i><span>Search here</span></a></li>
                                <li><a href="#"><i class="ti-heart"></i><span>Wishlist</span></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-navigation">
            <div class="container-fluid">
                <div class="primary-menu">
                    <div class="row">
                        <div class="col-lg-2 col-5">
                            <div class="site-branding">
                                <a href="index.php" class="brand-logo"><img src="assets/hbpimages/logo.png"
                                        alt="Brand Logo"></a>
                            </div>
                        </div>
                        <div class="col-lg-6 col-2">
                            <div class="nav-menu">
                                <div class="navbar-close"><i class="ti-close"></i></div>
                                <nav class="main-menu">
                                    <ul>
                                        <li class="menu-item"><a href="index.php" class="active">Home</a>

                                        </li>
                                     
                                        
                                                <li class="menu-item"><a href="explore-listing-boston.php">Explore</a></li>
                                                <li class="menu-item"><a href="eat-listing-boston.php">Eat</a></li>
                                                <li class="menu-item"><a href="shop-listing-boston.php">Shop</a></li>
                                                <li class="menu-item"><a href="fun-list.php">Fun</a></li>
                                       
                                       

                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="col-lg-4 col-5">
                            <!-- If we have time we can work on this -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    

   
    <!--====== End Header Section ======-->