<!DOCTYPE html>
<html lang="en">

<?php include 'header.php' ;?>

<body>

 <!--====== Start Hero Section ======-->
    <section class="hero-area">
        <div class="breadcrumbs-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="page-title">
                            <h1 class="title">Eat Page</h1>
                            <ul class="breadcrumbs-link">
                                <li><a href="index.html">Home</a></li>
                                <li class="active">List Layout</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--====== End Hero Section ======-->
    <!--====== Start Listing Section ======-->
    <section class="listing-list-area pt-120 pb-90">
        <div class="container">
            <div class="row">

                <div class="col-lg-8">

                    <div class="listing-item listing-list-item-two mb-60">
                        <div class="listing-thumbnail">
                            <img src="assets/hbpimages/boston-common-frog-pond-sm.jpeg" alt="Frog Pond">
                            <div class="thumbnail-meta d-flex justify-content-between align-items-center">
                                <div class="meta-icon-title d-flex align-items-center">
                                    <div class="icon">
                                        <i class="flaticon-government"></i>
                                    </div>
                                    <div class="title">
                                        <h6>Activities</h6>
                                    </div>
                                </div>
                                <span class="status st-open">Open</span>
                            </div>
                        </div>
                        <div class="listing-content">
                            <h3 class="title"><a href="FrogPondDetails.php">Ice Skating</a></h3>
                            <div class="ratings">
                                <ul class="ratings ratings-five">
                                    <li class="star"><i class="flaticon-star-1"></i></li>
                                    <li class="star"><i class="flaticon-star-1"></i></li>
                                    <li class="star"><i class="flaticon-star-1"></i></li>
                                    <li class="star"><i class="flaticon-star-1"></i></li>
                                    <li class="star"><i class="flaticon-star-1"></i></li>
                                    <li><span><a href="#">(1.3k Reviews)</a></span></li>
                                </ul>
                            </div>
                            <span class="price">$08.00 - $42.00</span>
                            <span class="phone-meta"><i class="ti-tablet"></i><a href="tel:+982653652-05">(617) - 635 - 2120 </a></span>
                            <div class="listing-meta">
                                <ul>
                                    <li><span><i class="ti-location-pin"></i>Frog Pond</span></li>
                                    <li><span><i class="ti-heart"></i><a href="#">Save</a></span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                        <div class="listing-item listing-list-item-two mb-60">
                            <div class="listing-thumbnail">
                                <img src="assets/hbpimages/redsox.jpg" alt="listing Image">
                                <div class="thumbnail-meta d-flex justify-content-between align-items-center">
                                    <div class="meta-icon-title d-flex align-items-center">
                                        <div class="icon">
                                            <i class="flaticon-baseball"></i>
                                        </div>
                                        <div class="title">
                                            <h6>Sports</h6>
                                        </div>
                                    </div>
                                    <span class="status st-open">Open</span>
                                </div>
                            </div>
                            <div class="listing-content">
                                <h3 class="title"><a href="RedSoxDetails.php">Red Sox Game</a></h3>
                                <div class="ratings">
                                    <ul class="ratings ratings-five">
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li><span><a href="#">(1.2k Reviews)</a></span></li>
                                    </ul>
                                </div>
                                <span class="price">$39.00 - $5,000.00</span>
                                <span class="phone-meta"><i class="ti-tablet"></i><a href="tel:+982653652-05">(877) - 733 - 7699</a></span>
                                <div class="listing-meta">
                                    <ul>
                                        <li><span><i class="ti-location-pin"></i>Fenway Park</span></li>
                                        <li><span><i class="ti-heart"></i><a href="#">Save</a></span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="listing-item listing-list-item-two mb-60">
                            <div class="listing-thumbnail">
                                <img src="assets/hbpimages/kayak.jpeg" alt="listing Image">
                                <div class="thumbnail-meta d-flex justify-content-between align-items-center">
                                    <div class="meta-icon-title d-flex align-items-center">
                                        <div class="icon">
                                            <i class="flaticon-government"></i>
                                        </div>
                                        <div class="title">
                                            <h6>Activities</h6>
                                        </div>
                                    </div>
                                    <span class="status st-open">Open</span>
                                </div>
                            </div>
                            <div class="listing-content">
                                <h3 class="title"><a href="KayakDetails.php">Kayaking</a></h3>
                                <div class="ratings">
                                    <ul class="ratings ratings-five">
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li><span><a href="#">(744 Reviews)</a></span></li>
                                    </ul>
                                </div>
                                <span class="price">$25.00 - $50.00</span>
                                <span class="phone-meta"><i class="ti-tablet"></i><a href="tel:+982653652-05">(617) - 965 - 5110</a></span>
                                <div class="listing-meta">
                                    <ul>
                                        <li><span><i class="ti-location-pin"></i>Charles River</span></li>
                                        <li><span><i class="ti-heart"></i><a href="#">Save</a></span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="listing-item listing-list-item-two mb-60">
                            <div class="listing-thumbnail">
                                <img src="assets/hbpimages/boston_symphony_orchestra_1494w.jpeg" alt="listing Image">
                                <div class="thumbnail-meta d-flex justify-content-between align-items-center">
                                    <div class="meta-icon-title d-flex align-items-center">
                                        <div class="icon">
                                            <i class="flaticon-dumbbell"></i>
                                        </div>
                                        <div class="title">
                                            <h6>Music</h6>
                                        </div>
                                    </div>
                                    <span class="status st-open">Open</span>
                                </div>
                            </div>
                            <div class="listing-content">
                                <h3 class="title"><a href="OrchestraDetails.php">Boston Symphony Orchestra</a></h3>
                                <div class="ratings">
                                    <ul class="ratings ratings-five">
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li><span><a href="#">(473 Reviews)</a></span></li>
                                    </ul>
                                </div>
                                <span class="price">$20.00 - $200.00</span>
                                <span class="phone-meta"><i class="ti-tablet"></i><a href="tel:+982653652-05">(617) - 266 - 1200</a></span>
                                <div class="listing-meta">
                                    <ul>
                                        <li><span><i class="ti-location-pin"></i>Fenway Neighborhood</span></li>
                                        <li><span><i class="ti-heart"></i><a href="#">Save</a></span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                      
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--====== End Listing Section ======-->
    <?php include 'footer.php' ;?>
   
</body>

</html>