<?php
function OpenCon()
 {
 $dbhost = "localhost";
 $dbuser = "hackbean_admin";
 $dbpass = "Hack@1234***";
 $db = "hackbean_2023";
 $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);
 
 return $conn;
 }
 
function CloseCon($conn)
 {
 $conn -> close();
 }
   
?>