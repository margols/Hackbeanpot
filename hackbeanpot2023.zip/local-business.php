<!DOCTYPE html>
<html lang="en">
<?php include 'header.php' ;?>

    <!--====== Start Listing Section ======-->
    <section class="listing-list-area pt-120 pb-90">
        <div class="container">
            <div class="row">

                <div class="col-lg-8">

                    <div class="listing-list-wrapper">
                        <div class="listing-item listing-list-item-two mb-60">
                            <div class="listing-thumbnail">
                                <img src="assets/hbpimages/Boston General Store.jpg" alt="listing Image">
                            </div>
                            <div class="listing-content">
                                <h3 class="title"><a href="bostonGeneralStore.php">Boston General Store</a></h3>
                                <div class="ratings">
                                    <ul class="ratings ratings-four">
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li><span><a href="#">(27 Reviews)</a></span></li>
                                    </ul>
                                </div>
                                <span class="phone-meta"><i class="ti-tablet"></i><a href="tel:(617) 232-0103">(617) 232-0103</a></span>
                                <div class="listing-meta">
                                    <ul>
                                        <li><span><i class="ti-location-pin"></i>Brookline, MA</span></li>
                                        <li><span><i class="ti-heart"></i><a href="#">Save</a></span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="listing-item listing-list-item-two mb-60">
                            <div class="listing-thumbnail">
                                <img src="assets/hbpimages/Brookline Booksmith 2.jpg" alt="listing Image">
                            </div>
                            <div class="listing-content">
                                <h3 class="title"><a href="brooklineBooksmith.php">Brookline Booksmith</a></h3>
                                <div class="ratings">
                                    <ul class="ratings ratings-five">
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li><span><a href="#">(455 Reviews)</a></span></li>
                                    </ul>
                                </div>
                                <span class="phone-meta"><i class="ti-tablet"></i><a href="tel:(617) 566-6660">(617) 566-6660</a></span>
                                <div class="listing-meta">
                                    <ul>
                                        <li><span><i class="ti-location-pin"></i>Brookline, MA</span></li>
                                        <li><span><i class="ti-heart"></i><a href="#">Save</a></span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="listing-item listing-list-item-two mb-60">
                            <div class="listing-thumbnail">
                                <img src="assets/hbpimages/Niche.jpg" alt="listing Image">
                            </div>
                            <div class="listing-content">
                                <h3 class="title"><a href="niche.php">Niche</a></h3>
                                <div class="ratings">
                                    <ul class="ratings ratings-five">
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li class="star"><i class="flaticon-star-1"></i></li>
                                        <li><span><a href="#">(81 Reviews)</a></span></li>
                                    </ul>
                                </div>
                                <span class="phone-meta"><i class="ti-tablet"></i><a href="tel:(857) 706-1164">(857) 706-1164</a></span>
                                <div class="listing-meta">
                                    <ul>
                                        <li><span><i class="ti-location-pin"></i>Somerville, MA</span></li>
                                        <li><span><i class="ti-heart"></i><a href="#">Save</a></span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--====== End Listing Section ======-->

<?php include 'footer.php' ;?>
</body>

</html>